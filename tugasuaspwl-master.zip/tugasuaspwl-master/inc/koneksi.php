<?php
$koneksi = new mysqli ("localhost","root","","data_pegawai");
?>

<!-- end -->